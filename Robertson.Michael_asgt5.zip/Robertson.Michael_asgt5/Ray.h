/* Michael Robertson
 * mirob2005@gmail.com, miro2005@csu.fullerton.edu
 * CS 566
 * HW3
 * Due 3/23/2012
 * SID: 892-32-2629
 *
 * $Id: Ray.h 1961 2010-02-24 08:46:53Z mshafae $
 *
 */

#ifndef _RAY_H_
#define _RAY_H_

class Ray{
public:
	Ray( );
	~Ray( );
};
#endif
//NOT CURRENTLY BEING USED