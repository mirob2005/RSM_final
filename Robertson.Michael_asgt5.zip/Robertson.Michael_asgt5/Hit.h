/* Michael Robertson
 * mirob2005@gmail.com, miro2005@csu.fullerton.edu
 * CS 566
 * HW3
 * Due 3/23/2012
 * SID: 892-32-2629
 *
 * $Id: Hit.h 1961 2010-02-24 08:46:53Z mshafae $
 *
 */

#ifndef _HIT_H_
#define _HIT_H_

class Hit{
public:
	Hit( );
	~Hit( );
};
#endif
//NOT CURRENTLY BEING USED